# Code Samples of oneAPI Threading Building Blocks (oneTBB)
This directory contains the examples referenced by the [oneAPI Threading Building Blocks Get Started Guide](https://www.intel.com/content/www/us/en/docs/onetbb/get-started-guide/current/overview.html)

| Code sample name | Description
|:--- |:---
| sub_string_finder | Finds largest matching substrings.
